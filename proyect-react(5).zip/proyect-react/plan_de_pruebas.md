# Plan de pruebas — Vivo-Sonido (React)

**Proyecto:** Vivo-Sonido — tienda de instrumentos musicales
**Integrantes:** Marco Gonzalez y Martin Arevalo
**Herramientas:** Vitest + React Testing Library (entorno jsdom)
**Comando:** `npm test` (o `npx vitest run`)
**Resultado de la última ejecución:** 10 archivos, 37 pruebas, todas aprobadas.

## 1. Objetivo

Comprobar que las funcionalidades críticas de la aplicación se comportan como se espera:
validaciones de formularios, carrito de compras, sesión y rutas privadas, filtrado,
favoritos, tema claro/oscuro y creación de productos en el panel de control.

## 2. Patrón de las pruebas

Todas las pruebas siguen el patrón **AAA**, marcado con comentarios en el código:

- **Arrange**: se prepara el escenario (datos de entrada, render del componente).
- **Act**: se ejecuta la acción que se quiere probar (clic, cambio de un campo, llamar la función).
- **Assert**: se verifica el resultado esperado.

## 3. Alcance

| Área | Qué se prueba | Archivo de prueba |
|---|---|---|
| Validaciones | Reglas de login, registro (incluidos los campos de contexto) y producto | `src/utils/validaciones.test.js` |
| Carrito | Agregar, quitar, cambiar cantidad y calcular total | `src/utils/carrito.test.js` |
| Sesión y autenticación | Guardado en localStorage y credenciales estáticas | `src/utils/sesion.test.js` |
| Productos y utilidades | Crear producto, filtrar, formato de precio, favoritos | `src/utils/productos.test.js` |
| Componentes | SelectorCantidad, TarjetaProducto, FormularioLogin, FormularioProducto | `src/components/**/*.test.jsx` |
| Rutas privadas | Acceso permitido o redirección al login | `src/routes/RutaPrivada.test.jsx` |
| Integración (App) | Estado compartido entre páginas y navegación | `src/App.test.jsx` |

Fuera de alcance: la reproducción del video de fondo y el aspecto visual (se revisan manualmente).

## 4. Escenarios de prueba

### 4.1 Validaciones (`validaciones.test.js`)

| ID | Escenario | Arrange | Act | Assert |
|---|---|---|---|---|
| PU-01 | Login con campos vacíos | correo y contraseña vacíos | `validarLogin` | errores de correo y contraseña obligatorios |
| PU-02 | Registro con números en el nombre | nombre `Marco123` | `validarRegistro` | "El nombre solo debe contener letras" |
| PU-03 | Registro con contraseñas distintas | confirmación diferente | `validarRegistro` | "Las contraseñas no coinciden" |
| PU-04 | Registro con datos válidos | todos los campos correctos, incluidos instrumento, nivel y años | `validarRegistro` | objeto de errores vacío |
| PU-05 | Producto con precio 0 | precio `0` | `validarProducto` | "El precio debe ser un número entero mayor a 0" |

### 4.2 Carrito (`carrito.test.js`)

| ID | Escenario | Arrange | Act | Assert |
|---|---|---|---|---|
| PU-06 | Agregar un producto que ya estaba | carrito con 1 unidad | `agregarItem` (+2) | cantidad 3 |
| PU-07 | Quitar un producto | carrito con 2 productos | `quitarItem` | queda solo el otro |
| PU-08 | Bajar la cantidad de 1 | 1 unidad | `cambiarCantidad` a 0 | el producto se elimina |
| PU-09 | Calcular el total | 2 productos con precios conocidos | `calcularTotal` | precio × cantidad sumado (4500) |

### 4.3 Sesión y autenticación (`sesion.test.js`)

| ID | Escenario | Arrange | Act | Assert |
|---|---|---|---|---|
| PU-10 | Guardar y leer la sesión | usuario de ejemplo | `guardarSesion` | `obtenerSesion` devuelve el usuario y existe en localStorage |
| PU-11 | Cerrar sesión | sesión guardada | `borrarSesion` | `obtenerSesion` devuelve `null` |
| PU-12 | Credenciales correctas | correo y contraseña del admin | `autenticar` | devuelve el usuario sin contraseña |
| PU-13 | Contraseña incorrecta | contraseña errónea | `autenticar` | devuelve `null` |

### 4.4 Productos y utilidades (`productos.test.js`)

| ID | Escenario | Arrange | Act | Assert |
|---|---|---|---|---|
| PU-14 | Crear producto del panel | datos del formulario | `crearProducto` | precio numérico e imagen genérica asignada |
| PU-15 | Filtrar catálogo | texto `bajo` y categoría `Cuerdas` | `filtrarProductos` | solo queda el bajo eléctrico |
| PU-16 | Formato de precio | valor 189990 | `formatearPrecio` | `$189.990` |
| PU-17 | Alternar favorito | lista vacía | `alternarFavorito` dos veces | se agrega y luego se quita |

### 4.5 Componentes

| ID | Escenario | Arrange | Act | Assert |
|---|---|---|---|---|
| PU-18 | SelectorCantidad avisa al sumar | cantidad 3 y `onSumar` simulado | clic en + | `onSumar` se llama y se ve el 3 |
| PU-19 | TarjetaProducto muestra sus datos | producto de ejemplo | render | nombre, descripción y precio con formato |
| PU-20 | TarjetaProducto agrega al carrito | `onAgregar` simulado | clic en Agregar | `onAgregar` recibe el id |
| PU-21 | TarjetaProducto favorito | `esFavorito = true` | render | aparece el botón "Guardado" |
| PU-22 | FormularioLogin vacío | formulario sin datos | clic en Ingresar | errores visibles y no ingresa |
| PU-23 | FormularioLogin credenciales malas | correo válido y clave incorrecta | enviar | "Correo o contraseña incorrectos" |
| PU-24 | FormularioLogin credenciales buenas | credenciales del admin | enviar | `onIngresar` recibe el usuario |
| PU-25 | FormularioProducto válido | datos completos | enviar | se crea el producto con imagen genérica |
| PU-26 | FormularioProducto vacío | formulario sin datos | enviar | errores visibles y no se crea |

### 4.6 Rutas privadas (`RutaPrivada.test.jsx`)

| ID | Escenario | Arrange | Act | Assert |
|---|---|---|---|---|
| PU-27 | Sin sesión | localStorage vacío | entrar a `/admin` | se muestra el login |
| PU-28 | Con sesión | sesión guardada | entrar a `/admin` | se muestra el contenido privado |

### 4.7 Integración (`App.test.jsx`)

| ID | Escenario | Arrange | Act | Assert |
|---|---|---|---|---|
| PU-29 | Carrito en el menú | página de productos | clic en Agregar | el menú muestra `Carrito (1)` |
| PU-30 | Favoritos | página de productos | clic en Favorito | el botón cambia a "Guardado" |
| PU-31 | Filtro dinámico | página de productos | escribir `bajo` | queda solo "Bajo eléctrico" |
| PU-32 | Tema claro/oscuro | página de inicio | clic en el botón de tema (dos veces) | `body` agrega y luego quita `tema-claro` |
| PU-33 | Panel sin sesión | sin sesión | entrar a `/admin` | se muestra el login |
| PU-34 | Inicio de sesión | página de login | enviar credenciales válidas | se ve "Mi perfil" y la sesión queda en localStorage |
| PU-35 | Crear producto en el panel | sesión de admin en `/admin` | completar y enviar el formulario | el producto aparece en la tabla |
| PU-36 | Cerrar sesión | sesión en `/perfil` | clic en Cerrar sesión | se borra la sesión y se muestra el login |
| PU-37 | Página 404 | ruta inexistente | entrar a la ruta | se muestra "Error 404" |

## 5. Pruebas manuales (no automatizadas)

- Diseño responsivo: revisar el menú colapsable, la grilla de tarjetas, los filtros y las tablas en un celular o con el modo responsive del navegador.
- Reproducción del video de fondo en todas las páginas.
- Revisar el aspecto del tema claro en cada página.

import { render, screen } from '@testing-library/react'
import { MemoryRouter, Routes, Route } from 'react-router-dom'
import { describe, it, expect, beforeEach } from 'vitest'
import RutaPrivada from './RutaPrivada'
import { guardarSesion } from '../utils/sesion'

function renderizarRutaProtegida() {
  render(
    <MemoryRouter initialEntries={['/admin']}>
      <Routes>
        <Route path="/admin" element={<RutaPrivada><p>Contenido privado</p></RutaPrivada>} />
        <Route path="/login" element={<p>Pantalla de login</p>} />
      </Routes>
    </MemoryRouter>
  )
}

describe('RutaPrivada', () => {
  beforeEach(() => {
    localStorage.clear()
  })

  it('Debe redirigir al login si no hay sesión guardada', () => {
    // Arrange
    // (localStorage vacío)

    // Act
    renderizarRutaProtegida()

    // Assert
    expect(screen.getByText('Pantalla de login')).toBeInTheDocument()
    expect(screen.queryByText('Contenido privado')).not.toBeInTheDocument()
  })

  it('Debe mostrar el contenido si hay una sesión guardada', () => {
    // Arrange
    guardarSesion({ correo: 'admin@vivosonido.cl', nombre: 'Administrador', rol: 'admin' })

    // Act
    renderizarRutaProtegida()

    // Assert
    expect(screen.getByText('Contenido privado')).toBeInTheDocument()
  })
})

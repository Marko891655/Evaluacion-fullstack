import { Navigate, useLocation } from 'react-router-dom'
import { obtenerSesion } from '../utils/sesion'

// Solo deja ver la página si hay una sesión guardada en localStorage.
// Si no la hay, redirige al login recordando a qué página quería entrar.
function RutaPrivada({ children }) {
  const ubicacion = useLocation()

  if (!obtenerSesion()) {
    return <Navigate to="/login" replace state={{ desde: ubicacion.pathname }} />
  }

  return children
}

export default RutaPrivada

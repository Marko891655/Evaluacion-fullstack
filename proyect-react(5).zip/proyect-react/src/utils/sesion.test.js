import { describe, it, expect, beforeEach } from 'vitest'
import { guardarSesion, obtenerSesion, borrarSesion } from './sesion'
import { autenticar } from './autenticacion'

describe('sesión y autenticación', () => {
  beforeEach(() => {
    localStorage.clear()
  })

  it('Debe guardar la sesión en localStorage y poder leerla', () => {
    // Arrange
    const usuario = { correo: 'admin@vivosonido.cl', nombre: 'Administrador', rol: 'admin' }

    // Act
    guardarSesion(usuario)

    // Assert
    expect(obtenerSesion()).toEqual(usuario)
    expect(localStorage.getItem('sesionVivoSonido')).not.toBeNull()
  })

  it('Debe borrar la sesión al cerrar sesión', () => {
    // Arrange
    guardarSesion({ correo: 'admin@vivosonido.cl', nombre: 'Administrador', rol: 'admin' })

    // Act
    borrarSesion()

    // Assert
    expect(obtenerSesion()).toBeNull()
  })

  it('Debe devolver el usuario (sin contraseña) si las credenciales son correctas', () => {
    // Arrange
    const correo = 'admin@vivosonido.cl'
    const contrasena = 'admin123'

    // Act
    const usuario = autenticar(correo, contrasena)

    // Assert
    expect(usuario).toEqual({ correo: 'admin@vivosonido.cl', nombre: 'Administrador', rol: 'admin' })
    expect(usuario.contrasena).toBeUndefined()
  })

  it('Debe devolver null si la contraseña es incorrecta', () => {
    // Arrange
    const correo = 'admin@vivosonido.cl'
    const contrasena = 'incorrecta'

    // Act
    const usuario = autenticar(correo, contrasena)

    // Assert
    expect(usuario).toBeNull()
  })
})

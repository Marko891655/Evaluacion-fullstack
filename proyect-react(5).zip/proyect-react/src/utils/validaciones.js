const REGEX_LETRAS = /^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/
const REGEX_CORREO = /^[^\s@]+@[^\s@]+\.[a-zA-Z]{2,}$/
const REGEX_CORREO_PERMITIDO = /^[^\s@]+@(gmail\.com|outlook\.com|duocuc\.cl)$/i
const REGEX_ENTERO = /^\d+$/

export function esCorreoValido(correo) {
  return REGEX_CORREO.test(correo)
}

export function soloLetras(texto) {
  return REGEX_LETRAS.test(texto)
}

// Cada función devuelve un objeto { campo: 'mensaje' }. Si está vacío, no hay errores.

export function validarLogin({ correo, contrasena }) {
  const errores = {}

  if (correo.trim() === '') {
    errores.correo = 'Debes ingresar tu correo electrónico'
  } else if (!esCorreoValido(correo)) {
    errores.correo = 'El correo ingresado no tiene un formato válido'
  }

  if (contrasena.trim() === '') {
    errores.contrasena = 'Debes ingresar tu contraseña'
  } else if (contrasena.length < 6) {
    errores.contrasena = 'La contraseña debe tener al menos 6 caracteres'
  }

  return errores
}

export function validarRegistro(datos) {
  const errores = {}

  if (datos.nombre.trim() === '') {
    errores.nombre = 'El nombre es obligatorio'
  } else if (!soloLetras(datos.nombre)) {
    errores.nombre = 'El nombre solo debe contener letras'
  }

  if (datos.apellido.trim() === '') {
    errores.apellido = 'El apellido es obligatorio'
  } else if (!soloLetras(datos.apellido)) {
    errores.apellido = 'El apellido solo debe contener letras'
  }

  if (datos.correo.trim() === '') {
    errores.correo = 'El correo es obligatorio'
  } else if (!REGEX_CORREO_PERMITIDO.test(datos.correo)) {
    errores.correo = 'El correo no tiene un formato válido (gmail.com, outlook.com o duocuc.cl)'
  }

  if (datos.fechaNacimiento.trim() === '') {
    errores.fechaNacimiento = 'Debes ingresar tu fecha de nacimiento'
  }

  if (datos.contrasena.trim() === '') {
    errores.contrasena = 'La contraseña es obligatoria'
  } else if (datos.contrasena.length < 6) {
    errores.contrasena = 'La contraseña debe tener al menos 6 caracteres'
  }

  if (datos.confirmarContrasena.trim() === '') {
    errores.confirmarContrasena = 'Debes confirmar tu contraseña'
  } else if (datos.confirmarContrasena !== datos.contrasena) {
    errores.confirmarContrasena = 'Las contraseñas no coinciden'
  }

  // Campos de contexto de la tienda de instrumentos
  if (datos.instrumento === '') {
    errores.instrumento = 'Selecciona tu instrumento principal'
  }

  if (datos.nivel === '') {
    errores.nivel = 'Selecciona tu nivel musical'
  }

  if (datos.aniosExperiencia.trim() === '') {
    errores.aniosExperiencia = 'Indica tus años de experiencia (0 si recién comienzas)'
  } else if (!REGEX_ENTERO.test(datos.aniosExperiencia)) {
    errores.aniosExperiencia = 'Los años de experiencia deben ser un número entero'
  } else if (Number(datos.aniosExperiencia) > 70) {
    errores.aniosExperiencia = 'Ingresa un valor entre 0 y 70'
  }

  return errores
}

export function validarProducto(datos) {
  const errores = {}

  if (datos.nombre.trim().length < 3) {
    errores.nombre = 'El nombre debe tener al menos 3 caracteres'
  }

  if (datos.descripcion.trim().length < 10) {
    errores.descripcion = 'La descripción debe tener al menos 10 caracteres'
  }

  if (datos.precio.trim() === '') {
    errores.precio = 'El precio es obligatorio'
  } else if (!REGEX_ENTERO.test(datos.precio) || Number(datos.precio) <= 0) {
    errores.precio = 'El precio debe ser un número entero mayor a 0'
  }

  if (datos.stock.trim() === '') {
    errores.stock = 'El stock es obligatorio'
  } else if (!REGEX_ENTERO.test(datos.stock)) {
    errores.stock = 'El stock debe ser un número entero (0 o más)'
  }

  if (datos.categoria === '') {
    errores.categoria = 'Selecciona una categoría'
  }

  return errores
}

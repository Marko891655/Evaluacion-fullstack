import imagenGenerica from '../assets/img/generico.svg'

// Convierte los datos del formulario del panel en un producto del catálogo.
// Como no se suben archivos, todos usan la misma imagen genérica.
export function crearProducto(datos) {
  return {
    id: `nuevo-${Date.now()}`,
    titulo: datos.nombre.trim(),
    imagen: imagenGenerica,
    descripcion: datos.descripcion.trim(),
    descripcionDetallada: datos.descripcion.trim(),
    precio: Number(datos.precio),
    infoAdicional: 'Producto agregado desde el panel de control.',
    categoria: datos.categoria,
    stock: Number(datos.stock),
  }
}

// Filtra por texto (en el nombre) y por categoría ('' = todas)
export function filtrarProductos(productos, texto, categoria) {
  const busqueda = texto.trim().toLowerCase()

  return productos.filter((producto) => {
    const coincideTexto = producto.titulo.toLowerCase().includes(busqueda)
    const coincideCategoria = categoria === '' || producto.categoria === categoria
    return coincideTexto && coincideCategoria
  })
}

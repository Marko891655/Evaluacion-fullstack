// Agrega el id si no estaba, o lo quita si ya estaba
export function alternarFavorito(favoritos, id) {
  if (favoritos.includes(id)) {
    return favoritos.filter((favorito) => favorito !== id)
  }
  return [...favoritos, id]
}

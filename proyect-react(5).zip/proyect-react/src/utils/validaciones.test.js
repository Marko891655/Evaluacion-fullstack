import { describe, it, expect } from 'vitest'
import { validarLogin, validarRegistro, validarProducto } from './validaciones'

const registroValido = {
  nombre: 'Marco',
  apellido: 'González',
  correo: 'marco@gmail.com',
  fechaNacimiento: '2000-05-10',
  instrumento: 'guitarra',
  nivel: 'intermedio',
  aniosExperiencia: '3',
  contrasena: 'clave123',
  confirmarContrasena: 'clave123',
  ofertas: false,
}

describe('validaciones', () => {
  it('Login: debe pedir correo y contraseña cuando están vacíos', () => {
    // Arrange
    const datos = { correo: '', contrasena: '' }

    // Act
    const errores = validarLogin(datos)

    // Assert
    expect(errores.correo).toBe('Debes ingresar tu correo electrónico')
    expect(errores.contrasena).toBe('Debes ingresar tu contraseña')
  })

  it('Registro: no debe aceptar números en el nombre', () => {
    // Arrange
    const datos = { ...registroValido, nombre: 'Marco123' }

    // Act
    const errores = validarRegistro(datos)

    // Assert
    expect(errores.nombre).toBe('El nombre solo debe contener letras')
  })

  it('Registro: debe detectar que las contraseñas no coinciden', () => {
    // Arrange
    const datos = { ...registroValido, confirmarContrasena: 'otraClave' }

    // Act
    const errores = validarRegistro(datos)

    // Assert
    expect(errores.confirmarContrasena).toBe('Las contraseñas no coinciden')
  })

  it('Registro: con todos los datos válidos no debe devolver errores', () => {
    // Arrange
    const datos = registroValido

    // Act
    const errores = validarRegistro(datos)

    // Assert
    expect(errores).toEqual({})
  })

  it('Producto: debe rechazar un precio igual a 0', () => {
    // Arrange
    const datos = { nombre: 'Ukelele', descripcion: 'Ukelele soprano de caoba', precio: '0', stock: '5', categoria: 'Cuerdas' }

    // Act
    const errores = validarProducto(datos)

    // Assert
    expect(errores.precio).toBe('El precio debe ser un número entero mayor a 0')
  })
})

import { describe, it, expect } from 'vitest'
import { crearProducto, filtrarProductos } from './productos'
import { formatearPrecio } from './formato'
import { alternarFavorito } from './favoritos'

const catalogo = [
  { id: 'a', titulo: 'Guitarra acústica', categoria: 'Cuerdas' },
  { id: 'b', titulo: 'Micrófono', categoria: 'Audio' },
  { id: 'c', titulo: 'Bajo eléctrico', categoria: 'Cuerdas' },
]

describe('productos y utilidades', () => {
  it('Debe crear un producto con precio numérico e imagen genérica', () => {
    // Arrange
    const datos = { nombre: ' Ukelele ', descripcion: 'Ukelele soprano de caoba', precio: '45990', stock: '4', categoria: 'Cuerdas' }

    // Act
    const producto = crearProducto(datos)

    // Assert
    expect(producto.titulo).toBe('Ukelele')
    expect(producto.precio).toBe(45990)
    expect(producto.imagen).toBeTruthy()
  })

  it('Debe filtrar el catálogo por texto y por categoría', () => {
    // Arrange
    const texto = 'bajo'
    const categoria = 'Cuerdas'

    // Act
    const resultado = filtrarProductos(catalogo, texto, categoria)

    // Assert
    expect(resultado).toHaveLength(1)
    expect(resultado[0].id).toBe('c')
  })

  it('Debe dar formato chileno al precio', () => {
    // Arrange
    const valor = 189990

    // Act
    const texto = formatearPrecio(valor)

    // Assert
    expect(texto).toBe('$189.990')
  })

  it('Debe agregar un favorito y quitarlo al alternarlo de nuevo', () => {
    // Arrange
    const inicial = []

    // Act
    const conFavorito = alternarFavorito(inicial, 'a')
    const sinFavorito = alternarFavorito(conFavorito, 'a')

    // Assert
    expect(conFavorito).toEqual(['a'])
    expect(sinFavorito).toEqual([])
  })
})

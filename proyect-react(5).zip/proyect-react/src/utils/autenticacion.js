import { usuarios } from '../data/usuarios'

// Devuelve el usuario (sin la contraseña) o null si las credenciales no coinciden
export function autenticar(correo, contrasena) {
  const encontrado = usuarios.find(
    (usuario) =>
      usuario.correo.toLowerCase() === correo.trim().toLowerCase() &&
      usuario.contrasena === contrasena
  )

  if (!encontrado) return null

  return { correo: encontrado.correo, nombre: encontrado.nombre, rol: encontrado.rol }
}

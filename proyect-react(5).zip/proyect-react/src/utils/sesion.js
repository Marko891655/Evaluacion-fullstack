// La sesión se guarda en localStorage para que sobreviva al recargar la página
const CLAVE_SESION = 'sesionVivoSonido'

export function guardarSesion(usuario) {
  localStorage.setItem(CLAVE_SESION, JSON.stringify(usuario))
}

export function obtenerSesion() {
  const guardada = localStorage.getItem(CLAVE_SESION)
  if (!guardada) return null

  try {
    return JSON.parse(guardada)
  } catch {
    return null
  }
}

export function borrarSesion() {
  localStorage.removeItem(CLAVE_SESION)
}

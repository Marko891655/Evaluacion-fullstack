// Un carrito es una lista de { id, cantidad }. Estas funciones NO modifican el
// arreglo original: devuelven uno nuevo (así funciona bien con useState).

export function agregarItem(carrito, id, cantidad = 1) {
  const existe = carrito.find((item) => item.id === id)

  if (existe) {
    return carrito.map((item) =>
      item.id === id ? { ...item, cantidad: item.cantidad + cantidad } : item
    )
  }

  return [...carrito, { id, cantidad }]
}

export function quitarItem(carrito, id) {
  return carrito.filter((item) => item.id !== id)
}

export function cambiarCantidad(carrito, id, cantidad) {
  if (cantidad < 1) {
    return quitarItem(carrito, id)
  }
  return carrito.map((item) => (item.id === id ? { ...item, cantidad } : item))
}

export function contarItems(carrito) {
  return carrito.reduce((total, item) => total + item.cantidad, 0)
}

// Une el carrito con el catálogo para mostrar nombre, precio y subtotal
export function detallarCarrito(carrito, productos) {
  return carrito
    .map((item) => {
      const producto = productos.find((p) => p.id === item.id)
      if (!producto) return null
      return {
        id: item.id,
        titulo: producto.titulo,
        precio: producto.precio,
        cantidad: item.cantidad,
        subtotal: producto.precio * item.cantidad,
      }
    })
    .filter((fila) => fila !== null)
}

export function calcularTotal(carrito, productos) {
  return detallarCarrito(carrito, productos).reduce((total, fila) => total + fila.subtotal, 0)
}

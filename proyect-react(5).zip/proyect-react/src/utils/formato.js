// 189990 -> $189.990 (formato chileno)
export function formatearPrecio(valor) {
  return '$' + Number(valor).toLocaleString('es-CL')
}

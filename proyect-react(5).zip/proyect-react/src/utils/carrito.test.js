import { describe, it, expect } from 'vitest'
import { agregarItem, quitarItem, cambiarCantidad, calcularTotal } from './carrito'

const productos = [
  { id: 'a', titulo: 'Producto A', precio: 1000 },
  { id: 'b', titulo: 'Producto B', precio: 2500 },
]

describe('carrito', () => {
  it('Debe sumar la cantidad si el producto ya estaba en el carrito', () => {
    // Arrange
    const carrito = [{ id: 'a', cantidad: 1 }]

    // Act
    const resultado = agregarItem(carrito, 'a', 2)

    // Assert
    expect(resultado).toEqual([{ id: 'a', cantidad: 3 }])
  })

  it('Debe quitar un producto del carrito', () => {
    // Arrange
    const carrito = [{ id: 'a', cantidad: 1 }, { id: 'b', cantidad: 2 }]

    // Act
    const resultado = quitarItem(carrito, 'a')

    // Assert
    expect(resultado).toEqual([{ id: 'b', cantidad: 2 }])
  })

  it('Debe eliminar el producto si la cantidad baja de 1', () => {
    // Arrange
    const carrito = [{ id: 'a', cantidad: 1 }]

    // Act
    const resultado = cambiarCantidad(carrito, 'a', 0)

    // Assert
    expect(resultado).toEqual([])
  })

  it('Debe calcular el total multiplicando precio por cantidad', () => {
    // Arrange
    const carrito = [{ id: 'a', cantidad: 2 }, { id: 'b', cantidad: 1 }]

    // Act
    const total = calcularTotal(carrito, productos)

    // Assert
    expect(total).toBe(4500)
  })
})

import PlantillaPagina from '../components/templates/PlantillaPagina'
import Seccion from '../components/molecules/Seccion'
import EnlaceBoton from '../components/atoms/EnlaceBoton'

function Error404({ encabezado }) {
  return (
    <PlantillaPagina {...encabezado}>
      <Seccion id="error-404" titulo="Error 404 - Página no encontrada">
        <p>La página que buscas no existe o fue movida.</p>
        <EnlaceBoton to="/">Volver al inicio</EnlaceBoton>
      </Seccion>
    </PlantillaPagina>
  )
}

export default Error404

import { useParams } from 'react-router-dom'
import PlantillaPagina from '../components/templates/PlantillaPagina'
import Seccion from '../components/molecules/Seccion'
import EnlaceBoton from '../components/atoms/EnlaceBoton'
import DetalleProducto from '../components/organisms/DetalleProducto'

function Producto({ productos, onAgregar, encabezado }) {
  const { id } = useParams()
  const producto = productos.find((item) => item.id === id)

  return (
    <PlantillaPagina {...encabezado}>
      <Seccion id="detalle">
        <EnlaceBoton to="/productos" variante="secundario">
          &larr; Volver al catalogo
        </EnlaceBoton>

        {producto ? (
          // key: al cambiar de producto se reinicia la cantidad elegida
          <DetalleProducto key={producto.id} producto={producto} onAgregar={onAgregar} />
        ) : (
          <p>El producto que buscas no existe.</p>
        )}
      </Seccion>
    </PlantillaPagina>
  )
}

export default Producto

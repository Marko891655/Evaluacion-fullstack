import { useState } from 'react'
import PlantillaPagina from '../components/templates/PlantillaPagina'
import Seccion from '../components/molecules/Seccion'
import ResumenPago from '../components/molecules/ResumenPago'
import EnlaceBoton from '../components/atoms/EnlaceBoton'
import Mensaje from '../components/atoms/Mensaje'
import TablaCarrito from '../components/organisms/TablaCarrito'
import { detallarCarrito, calcularTotal } from '../utils/carrito'

function Carrito({ productos, carrito, onCambiarCantidad, onQuitar, onVaciar, encabezado }) {
  const [compraConfirmada, setCompraConfirmada] = useState(false)

  const filas = detallarCarrito(carrito, productos)
  const total = calcularTotal(carrito, productos)

  const confirmarCompra = () => {
    onVaciar()
    setCompraConfirmada(true)
  }

  return (
    <PlantillaPagina {...encabezado}>
      <Seccion id="carrito" titulo="Carrito de compras">
        {filas.length > 0 ? (
          <>
            <TablaCarrito filas={filas} onCambiarCantidad={onCambiarCantidad} onQuitar={onQuitar} />
            <ResumenPago total={total} onConfirmar={confirmarCompra} />
          </>
        ) : (
          <>
            {compraConfirmada ? (
              <Mensaje texto="Compra confirmada. ¡Gracias por tu compra en Vivo-Sonido!" />
            ) : (
              <p>Tu carrito está vacío.</p>
            )}
            <EnlaceBoton to="/productos">Ver productos</EnlaceBoton>
          </>
        )}
      </Seccion>
    </PlantillaPagina>
  )
}

export default Carrito

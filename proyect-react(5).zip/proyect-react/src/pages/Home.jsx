import PlantillaPagina from '../components/templates/PlantillaPagina'
import Seccion from '../components/molecules/Seccion'
import EnlaceBoton from '../components/atoms/EnlaceBoton'
import GaleriaDestacados from '../components/organisms/GaleriaDestacados'

const idsDestacados = ['acustica', 'electrica', 'bateria']

function Home({ productos, encabezado }) {
  const destacados = idsDestacados
    .map((id) => productos.find((producto) => producto.id === id))
    .filter((producto) => producto !== undefined)

  return (
    <PlantillaPagina {...encabezado}>
      <Seccion id="inicio" titulo="Bienvenidos a Vivo-Sonido">
        <p>
          Somos una tienda especializada en instrumentos musicales y accesorios para musicos de todos los niveles.
          Desde guitarras acusticas para tus primeros acordes hasta amplificadores y micrófonos para tus
          presentaciones en vivo, en Vivo-Sonido encuentras todo lo que necesitas para hacer sonar tu música.
        </p>
        <p>
          Explora nuestro catalogo completo y descubre instrumentos, accesorios y equipamiento seleccionado para
          acompañarte en cada etapa de tu camino musical.
        </p>
        <EnlaceBoton to="/productos">Ver catalogo completo</EnlaceBoton>
      </Seccion>

      <Seccion id="destacados" titulo="Algunos de nuestros productos">
        <p>Una pequeña muestra de lo que vas a encontrar en la tienda.</p>
        <GaleriaDestacados productos={destacados} />
      </Seccion>
    </PlantillaPagina>
  )
}

export default Home

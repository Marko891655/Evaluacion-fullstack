import { useNavigate } from 'react-router-dom'
import PlantillaPagina from '../components/templates/PlantillaPagina'
import Seccion from '../components/molecules/Seccion'
import Boton from '../components/atoms/Boton'
import DatosPerfil from '../components/organisms/DatosPerfil'
import ListaFavoritos from '../components/organisms/ListaFavoritos'

function Perfil({ sesion, productos, favoritos, onCerrarSesion, encabezado }) {
  const navegar = useNavigate()
  const productosFavoritos = productos.filter((producto) => favoritos.includes(producto.id))

  const salir = () => {
    onCerrarSesion()
    navegar('/login')
  }

  // Mientras se cierra la sesión puede haber un render sin usuario: no mostramos nada
  if (!sesion) return null

  return (
    <PlantillaPagina {...encabezado}>
      <Seccion id="perfil" titulo="Mi perfil">
        <DatosPerfil sesion={sesion} />
        <Boton variante="secundario" onClick={salir}>
          Cerrar sesión
        </Boton>
      </Seccion>

      <Seccion id="favoritos" titulo="Mis productos favoritos">
        <ListaFavoritos productos={productosFavoritos} />
      </Seccion>
    </PlantillaPagina>
  )
}

export default Perfil

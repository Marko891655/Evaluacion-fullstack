import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import PlantillaPagina from '../components/templates/PlantillaPagina'
import Seccion from '../components/molecules/Seccion'
import FormularioProducto from '../components/organisms/FormularioProducto'
import TablaProductosAdmin from '../components/organisms/TablaProductosAdmin'

// Panel de control: crear y eliminar productos del catálogo (en memoria)
function Panel({ productos, onAgregarProducto, onEliminarProducto, encabezado }) {
  return (
    <PlantillaPagina {...encabezado}>
      <Row>
        <Col lg={5}>
          <Seccion id="nuevo-producto" titulo="Registrar producto">
            <FormularioProducto onAgregarProducto={onAgregarProducto} />
          </Seccion>
        </Col>
        <Col lg={7}>
          <Seccion id="catalogo-admin" titulo="Productos del catálogo">
            <TablaProductosAdmin productos={productos} onEliminar={onEliminarProducto} />
          </Seccion>
        </Col>
      </Row>
    </PlantillaPagina>
  )
}

export default Panel

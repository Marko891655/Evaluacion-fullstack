import { useLocation, useNavigate } from 'react-router-dom'
import PlantillaPagina from '../components/templates/PlantillaPagina'
import Seccion from '../components/molecules/Seccion'
import FormularioLogin from '../components/organisms/FormularioLogin'

function Login({ onIniciarSesion, encabezado }) {
  const navegar = useNavigate()
  const ubicacion = useLocation()

  // Si venía de una página protegida, vuelve ahí; si no, va a Mi perfil
  const destino = ubicacion.state?.desde || '/perfil'

  const ingresar = (usuario) => {
    onIniciarSesion(usuario)
    navegar(destino)
  }

  return (
    <PlantillaPagina {...encabezado}>
      <Seccion id="login" titulo="Iniciar sesion">
        <p>Ingresa tus datos para acceder a tu cuenta de Vivo-Sonido.</p>
        <FormularioLogin onIngresar={ingresar} />
      </Seccion>
    </PlantillaPagina>
  )
}

export default Login

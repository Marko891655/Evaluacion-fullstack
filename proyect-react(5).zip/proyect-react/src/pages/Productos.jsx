import { useState } from 'react'
import PlantillaPagina from '../components/templates/PlantillaPagina'
import Seccion from '../components/molecules/Seccion'
import FiltroProductos from '../components/organisms/FiltroProductos'
import GaleriaProductos from '../components/organisms/GaleriaProductos'
import { filtrarProductos } from '../utils/productos'

function Productos({ productos, favoritos, onAlternarFavorito, onAgregar, encabezado }) {
  const [texto, setTexto] = useState('')
  const [categoria, setCategoria] = useState('')

  const visibles = filtrarProductos(productos, texto, categoria)

  return (
    <PlantillaPagina {...encabezado}>
      <Seccion id="catalogo" titulo="Catálogo de productos">
        <p>
          Encuentra todo lo que necesitas para tocar, grabar y presentarte en vivo. Instrumentos, amplificación y
          accesorios seleccionados para músicos de cualquier nivel.
        </p>

        <FiltroProductos
          texto={texto}
          categoria={categoria}
          onCambiarTexto={setTexto}
          onCambiarCategoria={setCategoria}
        />

        {visibles.length > 0 ? (
          <GaleriaProductos
            productos={visibles}
            favoritos={favoritos}
            onAlternarFavorito={onAlternarFavorito}
            onAgregar={onAgregar}
          />
        ) : (
          <p>No se encontraron productos con ese filtro.</p>
        )}
      </Seccion>
    </PlantillaPagina>
  )
}

export default Productos

import PlantillaPagina from '../components/templates/PlantillaPagina'
import Seccion from '../components/molecules/Seccion'
import FormularioRegistro from '../components/organisms/FormularioRegistro'

function Registro({ encabezado }) {
  return (
    <PlantillaPagina {...encabezado}>
      <Seccion id="registro" titulo="Crear una cuenta">
        <p>Registrate para guardar tus datos y agilizar tus proximas compras.</p>
        <FormularioRegistro />
      </Seccion>
    </PlantillaPagina>
  )
}

export default Registro

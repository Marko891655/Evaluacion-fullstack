import imgAcustica from '../assets/img/acustica.png'
import imgElectrica from '../assets/img/electrica.png'
import imgBajo from '../assets/img/bajo.png'
import imgBateria from '../assets/img/bateria.png'
import imgAmplificador from '../assets/img/amplificador.png'
import imgMicro from '../assets/img/micro.png'
import imgPedal from '../assets/img/pedal.png'
import imgPuas from '../assets/img/puas.png'
import imgFunda from '../assets/img/funda.png'

export const categorias = ['Cuerdas', 'Percusión', 'Audio', 'Accesorios']

// Catálogo inicial (mismos productos del sitio HTML original)
export const productosIniciales = [
  {
    id: 'acustica',
    titulo: 'Guitarra acústica',
    imagen: imgAcustica,
    descripcion: 'El instrumento ideal para el folk, el pop, el rock acústico y la cantautoría.',
    descripcionDetallada: 'Guitarra acústica de cuerpo clásico, tapa de cedro macizo y mástil de caoba. Ideal para principiantes y cantautores que buscan un sonido cálido y versátil.',
    precio: 189990,
    infoAdicional: 'Incluye funda básica. Cuerdas de nylon.',
    categoria: 'Cuerdas',
    stock: 8,
  },
  {
    id: 'electrica',
    titulo: 'Guitarra eléctrica',
    imagen: imgElectrica,
    descripcion: 'La reina indiscutible del rock, el blues, el pop y el metal.',
    descripcionDetallada: 'Cuerpo tipo stratocaster, tres pastillas single-coil y mástil de arce. Perfecta para quienes buscan versatilidad tonal en vivo o en estudio.',
    precio: 259990,
    infoAdicional: 'No incluye amplificador ni cable.',
    categoria: 'Cuerdas',
    stock: 5,
  },
  {
    id: 'bajo',
    titulo: 'Bajo eléctrico',
    imagen: imgBajo,
    descripcion: 'El estándar global y la base rítmica y armónica de cualquier banda.',
    descripcionDetallada: 'Bajo de 4 cuerdas con cuerpo sólido y pastillas activas, pensado para estilos que van del funk al rock.',
    precio: 229990,
    infoAdicional: 'Incluye correa y cable de 3 metros.',
    categoria: 'Cuerdas',
    stock: 4,
  },
  {
    id: 'bateria',
    titulo: 'Batería',
    imagen: imgBateria,
    descripcion: 'El corazón rítmico de cualquier banda, lista para ensayo o escenario.',
    descripcionDetallada: 'Set de batería acústica de 5 piezas con platillos incluidos, ideal para ensayo y presentaciones en vivo.',
    precio: 499990,
    infoAdicional: 'Incluye baquetas y banco.',
    categoria: 'Percusión',
    stock: 2,
  },
  {
    id: 'amplificador',
    titulo: 'Amplificador',
    imagen: imgAmplificador,
    descripcion: 'El santo grial del tono y la dinámica para guitarristas exigentes.',
    descripcionDetallada: 'Amplificador de 40W con canal limpio y distorsión, ecualizador de 3 bandas y salida para auriculares.',
    precio: 149990,
    infoAdicional: 'Requiere alimentación 220V.',
    categoria: 'Audio',
    stock: 6,
  },
  {
    id: 'micro',
    titulo: 'Micrófono',
    imagen: imgMicro,
    descripcion: 'El caballo de batalla indiscutible para presentaciones en vivo.',
    descripcionDetallada: 'Micrófono dinámico cardioide, resistente a la retroalimentación, ideal para voces e instrumentos en vivo.',
    precio: 59990,
    infoAdicional: 'No incluye cable XLR.',
    categoria: 'Audio',
    stock: 10,
  },
  {
    id: 'pedal',
    titulo: 'Pedal de sonido',
    imagen: imgPedal,
    descripcion: 'Diseñado para ofrecer una respuesta fluida a cada acorde.',
    descripcionDetallada: 'Pedal de distorsión analógico con controles de tono, nivel y ganancia, compatible con guitarra y bajo.',
    precio: 39990,
    infoAdicional: 'Funciona con pila de 9V (no incluida).',
    categoria: 'Audio',
    stock: 12,
  },
  {
    id: 'puas',
    titulo: 'Púas',
    imagen: imgPuas,
    descripcion: 'El estándar tradicional amado por generaciones de guitarristas.',
    descripcionDetallada: 'Pack de 6 púas de distintos grosores (thin, medium, heavy) para adaptarse a cualquier estilo de ejecución.',
    precio: 2990,
    infoAdicional: 'Pack de 6 unidades.',
    categoria: 'Accesorios',
    stock: 100,
  },
  {
    id: 'funda',
    titulo: 'Funda',
    imagen: imgFunda,
    descripcion: 'La opción ligera y funcional para transportar tu guitarra a ensayos o toquines.',
    descripcionDetallada: 'Funda acolchada con correas ajustables y bolsillo frontal para accesorios, compatible con guitarras acústicas y eléctricas.',
    precio: 34990,
    infoAdicional: 'Compatible con la mayoría de los cuerpos de guitarra estándar.',
    categoria: 'Accesorios',
    stock: 15,
  },
]

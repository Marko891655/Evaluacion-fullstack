// Arma los enlaces del menú según si hay una sesión iniciada
export function construirMenu(sesion, cantidadCarrito) {
  const base = [
    { href: '/', etiqueta: 'Inicio' },
    { href: '/productos', etiqueta: 'Productos' },
    { href: '/carrito', etiqueta: `Carrito (${cantidadCarrito})` },
  ]

  if (sesion) {
    return [
      ...base,
      { href: '/perfil', etiqueta: 'Mi perfil' },
      { href: '/admin', etiqueta: 'Panel de control' },
    ]
  }

  return [
    ...base,
    { href: '/login', etiqueta: 'Iniciar sesión' },
    { href: '/registro', etiqueta: 'Registro' },
  ]
}

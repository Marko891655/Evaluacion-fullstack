// Credenciales estáticas para validar el inicio de sesión (no hay backend)
export const usuarios = [
  { correo: 'admin@vivosonido.cl', contrasena: 'admin123', nombre: 'Administrador', rol: 'admin' },
  { correo: 'cliente@gmail.com', contrasena: 'cliente123', nombre: 'Cliente Demo', rol: 'cliente' },
]

// Opciones de los campos de contexto del formulario de registro
export const instrumentos = [
  { valor: 'guitarra', etiqueta: 'Guitarra' },
  { valor: 'bajo', etiqueta: 'Bajo' },
  { valor: 'bateria', etiqueta: 'Batería' },
  { valor: 'voz', etiqueta: 'Voz' },
  { valor: 'otro', etiqueta: 'Otro' },
]

export const niveles = [
  { valor: 'principiante', etiqueta: 'Principiante' },
  { valor: 'intermedio', etiqueta: 'Intermedio' },
  { valor: 'avanzado', etiqueta: 'Avanzado' },
]

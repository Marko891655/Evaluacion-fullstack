import { render, screen, fireEvent } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { describe, it, expect, beforeEach, afterEach } from 'vitest'
import App from './App'
import { guardarSesion } from './utils/sesion'

function renderizarEn(ruta) {
  render(
    <MemoryRouter initialEntries={[ruta]}>
      <App />
    </MemoryRouter>
  )
}

const sesionAdmin = { correo: 'admin@vivosonido.cl', nombre: 'Administrador', rol: 'admin' }

// Pruebas de integración: verifican que el estado (useState) de App llega a las páginas
describe('App', () => {
  beforeEach(() => {
    localStorage.clear()
  })

  afterEach(() => {
    document.body.className = ''
  })

  it('Carrito: al agregar un producto el menú debe mostrar Carrito (1)', () => {
    // Arrange
    renderizarEn('/productos')
    expect(screen.getByText('Carrito (0)')).toBeInTheDocument()

    // Act
    fireEvent.click(screen.getAllByRole('button', { name: /agregar/i })[0])

    // Assert
    expect(screen.getByText('Carrito (1)')).toBeInTheDocument()
  })

  it('Favoritos: al presionar Favorito el botón debe cambiar a Guardado', () => {
    // Arrange
    renderizarEn('/productos')

    // Act
    fireEvent.click(screen.getAllByRole('button', { name: /favorito/i })[0])

    // Assert
    expect(screen.getAllByRole('button', { name: /guardado/i })).toHaveLength(1)
  })

  it('Filtro: al escribir "bajo" solo debe quedar el Bajo eléctrico', () => {
    // Arrange
    renderizarEn('/productos')

    // Act
    fireEvent.change(screen.getByLabelText(/buscar por nombre/i), { target: { value: 'bajo' } })

    // Assert
    const titulos = screen.getAllByRole('heading', { level: 3 })
    expect(titulos).toHaveLength(1)
    expect(titulos[0]).toHaveTextContent('Bajo eléctrico')
  })

  it('Tema: el botón del menú debe agregar y quitar la clase tema-claro del body', () => {
    // Arrange
    renderizarEn('/')

    // Act
    fireEvent.click(screen.getByRole('button', { name: /tema claro/i }))

    // Assert
    expect(document.body.classList.contains('tema-claro')).toBe(true)
    fireEvent.click(screen.getByRole('button', { name: /tema oscuro/i }))
    expect(document.body.classList.contains('tema-claro')).toBe(false)
  })

  it('Ruta privada: entrar a /admin sin sesión debe llevar al login', () => {
    // Arrange
    // (sin sesión en localStorage)

    // Act
    renderizarEn('/admin')

    // Assert
    expect(screen.getByRole('heading', { name: /iniciar sesion/i })).toBeInTheDocument()
    expect(screen.queryByText('Registrar producto')).not.toBeInTheDocument()
  })

  it('Login: con credenciales correctas debe guardar la sesión y mostrar Mi perfil', async () => {
    // Arrange
    renderizarEn('/login')

    // Act
    fireEvent.change(screen.getByLabelText(/correo/i), { target: { value: 'admin@vivosonido.cl' } })
    fireEvent.change(screen.getByLabelText(/contraseña/i), { target: { value: 'admin123' } })
    fireEvent.click(screen.getByRole('button', { name: /ingresar/i }))

    // Assert
    expect(await screen.findByRole('heading', { name: /mi perfil/i })).toBeInTheDocument()
    expect(localStorage.getItem('sesionVivoSonido')).not.toBeNull()
  })

  it('Panel: un producto creado debe aparecer en la tabla del catálogo', async () => {
    // Arrange
    guardarSesion(sesionAdmin)
    renderizarEn('/admin')

    // Act
    fireEvent.change(screen.getByLabelText(/^nombre/i), { target: { value: 'Ukelele soprano' } })
    fireEvent.change(screen.getByLabelText(/descripción/i), { target: { value: 'Ukelele de caoba para principiantes' } })
    fireEvent.change(screen.getByLabelText(/precio/i), { target: { value: '45990' } })
    fireEvent.change(screen.getByLabelText(/stock/i), { target: { value: '7' } })
    fireEvent.change(screen.getByLabelText(/categoría/i), { target: { value: 'Cuerdas' } })
    fireEvent.click(screen.getByRole('button', { name: /agregar producto/i }))

    // Assert
    expect(await screen.findByText('Ukelele soprano', { selector: 'td' })).toBeInTheDocument()
  })

  it('Cerrar sesión: debe borrar la sesión y llevar al login', async () => {
    // Arrange
    guardarSesion(sesionAdmin)
    renderizarEn('/perfil')

    // Act
    fireEvent.click(screen.getByRole('button', { name: /cerrar sesión/i }))

    // Assert
    expect(await screen.findByRole('heading', { name: /iniciar sesion/i })).toBeInTheDocument()
    expect(localStorage.getItem('sesionVivoSonido')).toBeNull()
  })

  it('Error 404: una ruta que no existe debe mostrar la página de error', () => {
    // Arrange
    // (ruta inexistente)

    // Act
    renderizarEn('/esta-ruta-no-existe')

    // Assert
    expect(screen.getByRole('heading', { name: /error 404/i })).toBeInTheDocument()
  })
})

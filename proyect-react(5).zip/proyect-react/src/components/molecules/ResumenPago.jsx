import Precio from '../atoms/Precio'
import Boton from '../atoms/Boton'

// Total del carrito + botón para confirmar la compra
function ResumenPago({ total, onConfirmar }) {
  return (
    <div className="resumen-pago">
      <Precio etiqueta="Total a pagar: " valor={total} />
      <Boton onClick={onConfirmar}>Confirmar compra</Boton>
    </div>
  )
}

export default ResumenPago

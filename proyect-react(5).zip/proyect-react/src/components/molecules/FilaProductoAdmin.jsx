import Boton from '../atoms/Boton'
import { formatearPrecio } from '../../utils/formato'

function FilaProductoAdmin({ producto, onEliminar }) {
  return (
    <tr>
      <td>
        <img className="miniatura" src={producto.imagen} alt={producto.titulo} />
      </td>
      <td>{producto.titulo}</td>
      <td>{producto.categoria}</td>
      <td>{formatearPrecio(producto.precio)}</td>
      <td>{producto.stock}</td>
      <td>
        <Boton variante="secundario" onClick={() => onEliminar(producto.id)}>
          Eliminar
        </Boton>
      </td>
    </tr>
  )
}

export default FilaProductoAdmin

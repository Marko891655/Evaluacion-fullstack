// Botones - y + con la cantidad en el medio. El estado vive en quien lo usa.
function SelectorCantidad({ cantidad, onSumar, onRestar, mostrarEtiqueta = true }) {
  return (
    <div className="cantidad-selector">
      {mostrarEtiqueta && <span className="etiqueta-cantidad">Cantidad:</span>}
      <button type="button" className="btn-cantidad" onClick={onRestar} aria-label="Restar una unidad">
        -
      </button>
      <span className="cantidad-valor">{cantidad}</span>
      <button type="button" className="btn-cantidad" onClick={onSumar} aria-label="Sumar una unidad">
        +
      </button>
    </div>
  )
}

export default SelectorCantidad

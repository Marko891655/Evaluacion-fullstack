import { Link } from 'react-router-dom'

// Un elemento del menú: enlace si tiene href, o botón si solo tiene onClick
function ItemMenu({ href, etiqueta, onClick }) {
  return (
    <li>
      {href ? (
        <Link to={href} onClick={onClick}>
          {etiqueta}
        </Link>
      ) : (
        <button type="button" onClick={onClick}>
          {etiqueta}
        </button>
      )}
    </li>
  )
}

export default ItemMenu

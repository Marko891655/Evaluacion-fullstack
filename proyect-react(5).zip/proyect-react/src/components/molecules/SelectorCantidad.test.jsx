import { render, screen, fireEvent } from '@testing-library/react'
import { describe, it, expect, vi } from 'vitest'
import SelectorCantidad from './SelectorCantidad'

describe('SelectorCantidad', () => {
  it('Debe avisar al hacer clic en + y mostrar la cantidad recibida', () => {
    // Arrange
    const onSumar = vi.fn()
    render(<SelectorCantidad cantidad={3} onSumar={onSumar} onRestar={() => {}} />)

    // Act
    fireEvent.click(screen.getByRole('button', { name: /sumar una unidad/i }))

    // Assert
    expect(onSumar).toHaveBeenCalledTimes(1)
    expect(screen.getByText('3')).toBeInTheDocument()
  })
})

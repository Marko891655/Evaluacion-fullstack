import ImagenProducto from '../atoms/ImagenProducto'
import Precio from '../atoms/Precio'
import Boton from '../atoms/Boton'
import EnlaceBoton from '../atoms/EnlaceBoton'

// Tarjeta del catálogo: imagen, nombre, descripción, precio y botones
function TarjetaProducto({ producto, esFavorito, onAlternarFavorito, onAgregar }) {
  return (
    <article className="tarjeta">
      <div className="espacio-imagen">
        <ImagenProducto src={producto.imagen} alt={producto.titulo} />
      </div>
      <div className="info-producto">
        <h3>{producto.titulo}</h3>
        <p>{producto.descripcion}</p>
        <Precio valor={producto.precio} />
        <div className="acciones-producto">
          <EnlaceBoton to={`/producto/${producto.id}`}>Ver detalle</EnlaceBoton>
          <Boton variante="secundario" onClick={() => onAgregar(producto.id)}>
            Agregar
          </Boton>
          <Boton variante="secundario" onClick={() => onAlternarFavorito(producto.id)}>
            {esFavorito ? '♥ Guardado' : '♡ Favorito'}
          </Boton>
        </div>
      </div>
    </article>
  )
}

export default TarjetaProducto

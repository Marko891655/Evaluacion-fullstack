import { render, screen, fireEvent } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { describe, it, expect, vi } from 'vitest'
import TarjetaProducto from './TarjetaProducto'

const producto = {
  id: 'acustica',
  titulo: 'Guitarra acústica',
  imagen: 'acustica.png',
  descripcion: 'Ideal para el folk',
  precio: 189990,
}

function renderizar(esFavorito, onAgregar = () => {}) {
  render(
    <MemoryRouter>
      <TarjetaProducto
        producto={producto}
        esFavorito={esFavorito}
        onAlternarFavorito={() => {}}
        onAgregar={onAgregar}
      />
    </MemoryRouter>
  )
}

describe('TarjetaProducto', () => {
  it('Debe mostrar el nombre, la descripción y el precio con formato', () => {
    // Arrange
    renderizar(false)

    // Act (solo renderiza)

    // Assert
    expect(screen.getByText('Guitarra acústica')).toBeInTheDocument()
    expect(screen.getByText('Ideal para el folk')).toBeInTheDocument()
    expect(screen.getByText('$189.990')).toBeInTheDocument()
  })

  it('Debe llamar a onAgregar con el id del producto al presionar Agregar', () => {
    // Arrange
    const onAgregar = vi.fn()
    renderizar(false, onAgregar)

    // Act
    fireEvent.click(screen.getByRole('button', { name: /agregar/i }))

    // Assert
    expect(onAgregar).toHaveBeenCalledWith('acustica')
  })

  it('Debe mostrar "Guardado" cuando el producto es favorito', () => {
    // Arrange
    renderizar(true)

    // Act (solo renderiza)

    // Assert
    expect(screen.getByRole('button', { name: /guardado/i })).toBeInTheDocument()
  })
})

import Form from 'react-bootstrap/Form'
import ErrorMensaje from '../atoms/ErrorMensaje'

// Etiqueta + campo (input, select o textarea) + mensaje de error.
// Si recibe "opciones" se dibuja un select; si recibe "filas", un textarea.
function CampoFormulario({
  id,
  etiqueta,
  valor,
  onChange,
  error,
  tipo = 'text',
  placeholder,
  opciones,
  opcionVacia = 'Selecciona una opción',
  filas,
  min,
}) {
  return (
    <Form.Group controlId={id}>
      <Form.Label>{etiqueta}</Form.Label>

      {opciones ? (
        <Form.Select name={id} value={valor} onChange={onChange}>
          <option value="">{opcionVacia}</option>
          {opciones.map((opcion) => (
            <option key={opcion.valor} value={opcion.valor}>
              {opcion.etiqueta}
            </option>
          ))}
        </Form.Select>
      ) : (
        <Form.Control
          name={id}
          type={tipo}
          value={valor}
          onChange={onChange}
          placeholder={placeholder}
          as={filas ? 'textarea' : 'input'}
          rows={filas}
          min={min}
        />
      )}

      {error !== undefined && <ErrorMensaje mensaje={error} />}
    </Form.Group>
  )
}

export default CampoFormulario

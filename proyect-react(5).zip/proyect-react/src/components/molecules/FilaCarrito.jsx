import SelectorCantidad from './SelectorCantidad'
import Boton from '../atoms/Boton'
import { formatearPrecio } from '../../utils/formato'

function FilaCarrito({ fila, onCambiarCantidad, onQuitar }) {
  return (
    <tr>
      <td>{fila.titulo}</td>
      <td>{formatearPrecio(fila.precio)}</td>
      <td>
        <SelectorCantidad
          cantidad={fila.cantidad}
          mostrarEtiqueta={false}
          onSumar={() => onCambiarCantidad(fila.id, fila.cantidad + 1)}
          onRestar={() => onCambiarCantidad(fila.id, fila.cantidad - 1)}
        />
      </td>
      <td>{formatearPrecio(fila.subtotal)}</td>
      <td>
        <Boton variante="secundario" onClick={() => onQuitar(fila.id)}>
          Quitar
        </Boton>
      </td>
    </tr>
  )
}

export default FilaCarrito

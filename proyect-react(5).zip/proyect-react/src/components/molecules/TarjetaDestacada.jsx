import ImagenProducto from '../atoms/ImagenProducto'
import EnlaceBoton from '../atoms/EnlaceBoton'

// Tarjeta reducida de la página de inicio: solo imagen, nombre y "Ver más"
function TarjetaDestacada({ producto }) {
  return (
    <article className="tarjeta">
      <div className="espacio-imagen">
        <ImagenProducto src={producto.imagen} alt={producto.titulo} />
      </div>
      <div className="info-producto">
        <h3>{producto.titulo}</h3>
        <EnlaceBoton to={`/producto/${producto.id}`}>Ver mas</EnlaceBoton>
      </div>
    </article>
  )
}

export default TarjetaDestacada

// Bloque con el fondo oscuro del sitio. El título es opcional.
function Seccion({ id, titulo, children }) {
  return (
    <section id={id} className="seccion">
      {titulo && <h2>{titulo}</h2>}
      {children}
    </section>
  )
}

export default Seccion

import { render, screen, fireEvent } from '@testing-library/react'
import { MemoryRouter } from 'react-router-dom'
import { describe, it, expect, vi } from 'vitest'
import FormularioLogin from './FormularioLogin'

function llenarYEnviar(correo, contrasena) {
  fireEvent.change(screen.getByLabelText(/correo/i), { target: { value: correo } })
  fireEvent.change(screen.getByLabelText(/contraseña/i), { target: { value: contrasena } })
  fireEvent.click(screen.getByRole('button', { name: /ingresar/i }))
}

describe('FormularioLogin', () => {
  it('Debe mostrar errores y no ingresar si los campos están vacíos', () => {
    // Arrange
    const onIngresar = vi.fn()
    render(<MemoryRouter><FormularioLogin onIngresar={onIngresar} /></MemoryRouter>)

    // Act
    fireEvent.click(screen.getByRole('button', { name: /ingresar/i }))

    // Assert
    expect(screen.getByText('Debes ingresar tu correo electrónico')).toBeInTheDocument()
    expect(onIngresar).not.toHaveBeenCalled()
  })

  it('Debe avisar si las credenciales no coinciden con ningún usuario', () => {
    // Arrange
    const onIngresar = vi.fn()
    render(<MemoryRouter><FormularioLogin onIngresar={onIngresar} /></MemoryRouter>)

    // Act
    llenarYEnviar('admin@vivosonido.cl', 'claveMala')

    // Assert
    expect(screen.getByText('Correo o contraseña incorrectos')).toBeInTheDocument()
    expect(onIngresar).not.toHaveBeenCalled()
  })

  it('Debe entregar el usuario cuando las credenciales son correctas', () => {
    // Arrange
    const onIngresar = vi.fn()
    render(<MemoryRouter><FormularioLogin onIngresar={onIngresar} /></MemoryRouter>)

    // Act
    llenarYEnviar('admin@vivosonido.cl', 'admin123')

    // Assert
    expect(onIngresar).toHaveBeenCalledWith({
      correo: 'admin@vivosonido.cl',
      nombre: 'Administrador',
      rol: 'admin',
    })
  })
})

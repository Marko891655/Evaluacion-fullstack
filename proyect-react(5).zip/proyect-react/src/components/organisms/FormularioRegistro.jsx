import { useState } from 'react'
import { Link } from 'react-router-dom'
import Form from 'react-bootstrap/Form'
import CampoFormulario from '../molecules/CampoFormulario'
import Boton from '../atoms/Boton'
import Mensaje from '../atoms/Mensaje'
import { validarRegistro } from '../../utils/validaciones'
import { instrumentos, niveles } from '../../data/opciones'

const valoresIniciales = {
  nombre: '',
  apellido: '',
  correo: '',
  fechaNacimiento: '',
  instrumento: '',
  nivel: '',
  aniosExperiencia: '',
  contrasena: '',
  confirmarContrasena: '',
  ofertas: false,
}

function FormularioRegistro() {
  const [valores, setValores] = useState(valoresIniciales)
  const [errores, setErrores] = useState({})
  const [mensaje, setMensaje] = useState('')

  const cambiar = (e) => {
    setValores({ ...valores, [e.target.name]: e.target.value })
  }

  const cambiarOfertas = (e) => {
    setValores({ ...valores, ofertas: e.target.checked })
  }

  const enviar = (e) => {
    e.preventDefault()
    const nuevosErrores = validarRegistro(valores)
    setErrores(nuevosErrores)
    setMensaje('')

    if (Object.keys(nuevosErrores).length > 0) return

    setMensaje('Registro exitoso. ¡Bienvenido a Vivo-Sonido!')
    setValores(valoresIniciales)
  }

  return (
    <Form onSubmit={enviar} noValidate>
      <fieldset>
        <legend>Datos de registro</legend>

        <CampoFormulario id="nombre" etiqueta="Nombre:" placeholder="Ingresa tu nombre"
          valor={valores.nombre} onChange={cambiar} error={errores.nombre || ''} />

        <CampoFormulario id="apellido" etiqueta="Apellido:" placeholder="Ingresa tu apellido"
          valor={valores.apellido} onChange={cambiar} error={errores.apellido || ''} />

        <CampoFormulario id="correo" etiqueta="Correo electronico:" tipo="email" placeholder="tu@correo.com"
          valor={valores.correo} onChange={cambiar} error={errores.correo || ''} />

        <CampoFormulario id="fechaNacimiento" etiqueta="Fecha de nacimiento:" tipo="date"
          valor={valores.fechaNacimiento} onChange={cambiar} error={errores.fechaNacimiento || ''} />

        <CampoFormulario id="instrumento" etiqueta="Instrumento principal:" opciones={instrumentos}
          valor={valores.instrumento} onChange={cambiar} error={errores.instrumento || ''} />

        <CampoFormulario id="nivel" etiqueta="Nivel musical:" opciones={niveles}
          valor={valores.nivel} onChange={cambiar} error={errores.nivel || ''} />

        <CampoFormulario id="aniosExperiencia" etiqueta="Años de experiencia tocando:" tipo="number" min="0"
          placeholder="Ej: 3" valor={valores.aniosExperiencia} onChange={cambiar}
          error={errores.aniosExperiencia || ''} />

        <CampoFormulario id="contrasena" etiqueta="Contraseña:" tipo="password" placeholder="Mínimo 6 caracteres"
          valor={valores.contrasena} onChange={cambiar} error={errores.contrasena || ''} />

        <CampoFormulario id="confirmarContrasena" etiqueta="Confirmar contraseña:" tipo="password"
          placeholder="Repite tu contraseña" valor={valores.confirmarContrasena} onChange={cambiar}
          error={errores.confirmarContrasena || ''} />

        <Form.Check
          type="checkbox"
          id="ofertas"
          name="ofertas"
          label="Quiero recibir ofertas de instrumentos y accesorios"
          checked={valores.ofertas}
          onChange={cambiarOfertas}
        />

        <Boton tipo="submit">Registrarme</Boton>
        <Mensaje texto={mensaje} />
      </fieldset>

      <p className="enlace-secundario">
        ¿Ya tienes cuenta? <Link to="/login">Inicia sesion aqui</Link>
      </p>
      <p className="enlace-secundario">
        <Link to="/">Volver a la pagina principal</Link>
      </p>
    </Form>
  )
}

export default FormularioRegistro

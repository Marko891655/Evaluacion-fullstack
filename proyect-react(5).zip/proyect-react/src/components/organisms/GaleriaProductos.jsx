import TarjetaProducto from '../molecules/TarjetaProducto'

function GaleriaProductos({ productos, favoritos, onAlternarFavorito, onAgregar }) {
  return (
    <div className="galeria">
      {productos.map((producto) => (
        <TarjetaProducto
          key={producto.id}
          producto={producto}
          esFavorito={favoritos.includes(producto.id)}
          onAlternarFavorito={onAlternarFavorito}
          onAgregar={onAgregar}
        />
      ))}
    </div>
  )
}

export default GaleriaProductos

function Footer() {
  return (
    <footer id="pie">
      <p>
        <small>&copy; 2025 Vivo-Sonido - Todos los derechos reservados</small>
      </p>
    </footer>
  )
}

export default Footer

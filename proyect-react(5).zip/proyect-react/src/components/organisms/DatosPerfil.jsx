function DatosPerfil({ sesion }) {
  const rol = sesion.rol === 'admin' ? 'Administrador' : 'Cliente'

  return (
    <div className="datos-perfil">
      <p>
        <strong>Nombre:</strong> {sesion.nombre}
      </p>
      <p>
        <strong>Correo:</strong> {sesion.correo}
      </p>
      <p>
        <strong>Rol:</strong> {rol}
      </p>
    </div>
  )
}

export default DatosPerfil

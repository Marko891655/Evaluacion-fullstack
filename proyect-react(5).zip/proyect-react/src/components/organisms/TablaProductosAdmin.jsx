import Table from 'react-bootstrap/Table'
import FilaProductoAdmin from '../molecules/FilaProductoAdmin'

function TablaProductosAdmin({ productos, onEliminar }) {
  return (
    <Table responsive hover>
      <thead>
        <tr>
          <th>Imagen</th>
          <th>Nombre</th>
          <th>Categoría</th>
          <th>Precio</th>
          <th>Stock</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        {productos.map((producto) => (
          <FilaProductoAdmin key={producto.id} producto={producto} onEliminar={onEliminar} />
        ))}
      </tbody>
    </Table>
  )
}

export default TablaProductosAdmin

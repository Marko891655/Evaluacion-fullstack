import { useState } from 'react'
import Form from 'react-bootstrap/Form'
import CampoFormulario from '../molecules/CampoFormulario'
import Boton from '../atoms/Boton'
import Mensaje from '../atoms/Mensaje'
import { validarProducto } from '../../utils/validaciones'
import { crearProducto } from '../../utils/productos'
import { categorias } from '../../data/productos'

const opcionesCategoria = categorias.map((categoria) => ({ valor: categoria, etiqueta: categoria }))

const valoresIniciales = { nombre: '', descripcion: '', precio: '', stock: '', categoria: '' }

// Formulario del panel de control: crea un producto nuevo (solo en memoria)
function FormularioProducto({ onAgregarProducto }) {
  const [valores, setValores] = useState(valoresIniciales)
  const [errores, setErrores] = useState({})
  const [mensaje, setMensaje] = useState('')

  const cambiar = (e) => {
    setValores({ ...valores, [e.target.name]: e.target.value })
  }

  const enviar = (e) => {
    e.preventDefault()
    const nuevosErrores = validarProducto(valores)
    setErrores(nuevosErrores)
    setMensaje('')

    if (Object.keys(nuevosErrores).length > 0) return

    onAgregarProducto(crearProducto(valores))
    setMensaje('Producto agregado al catálogo (se guarda solo en memoria).')
    setValores(valoresIniciales)
  }

  return (
    <Form onSubmit={enviar} noValidate>
      <fieldset>
        <legend>Datos del producto</legend>

        <CampoFormulario id="nombre" etiqueta="Nombre:" placeholder="Ej: Ukelele soprano"
          valor={valores.nombre} onChange={cambiar} error={errores.nombre || ''} />

        <CampoFormulario id="descripcion" etiqueta="Descripción:" filas={3} placeholder="Describe el producto"
          valor={valores.descripcion} onChange={cambiar} error={errores.descripcion || ''} />

        <CampoFormulario id="precio" etiqueta="Precio (CLP):" tipo="number" min="1" placeholder="Ej: 45990"
          valor={valores.precio} onChange={cambiar} error={errores.precio || ''} />

        <CampoFormulario id="stock" etiqueta="Stock disponible:" tipo="number" min="0" placeholder="Ej: 10"
          valor={valores.stock} onChange={cambiar} error={errores.stock || ''} />

        <CampoFormulario id="categoria" etiqueta="Categoría:" opciones={opcionesCategoria}
          valor={valores.categoria} onChange={cambiar} error={errores.categoria || ''} />

        <Boton tipo="submit">Agregar producto</Boton>
        <Mensaje texto={mensaje} />
      </fieldset>
    </Form>
  )
}

export default FormularioProducto

import { useState } from 'react'
import { Link } from 'react-router-dom'
import Form from 'react-bootstrap/Form'
import CampoFormulario from '../molecules/CampoFormulario'
import Boton from '../atoms/Boton'
import ErrorMensaje from '../atoms/ErrorMensaje'
import { validarLogin } from '../../utils/validaciones'
import { autenticar } from '../../utils/autenticacion'

function FormularioLogin({ onIngresar }) {
  const [valores, setValores] = useState({ correo: '', contrasena: '' })
  const [errores, setErrores] = useState({})
  const [errorGeneral, setErrorGeneral] = useState('')

  const cambiar = (e) => {
    setValores({ ...valores, [e.target.name]: e.target.value })
  }

  const enviar = (e) => {
    e.preventDefault()
    const nuevosErrores = validarLogin(valores)
    setErrores(nuevosErrores)
    setErrorGeneral('')

    if (Object.keys(nuevosErrores).length > 0) return

    const usuario = autenticar(valores.correo, valores.contrasena)
    if (!usuario) {
      setErrorGeneral('Correo o contraseña incorrectos')
      return
    }

    onIngresar(usuario)
  }

  return (
    <Form onSubmit={enviar} noValidate>
      <fieldset>
        <legend>Acceso a tu cuenta</legend>

        <CampoFormulario
          id="correo"
          etiqueta="Correo electronico:"
          tipo="email"
          placeholder="tu@correo.com"
          valor={valores.correo}
          onChange={cambiar}
          error={errores.correo || ''}
        />

        <CampoFormulario
          id="contrasena"
          etiqueta="Contraseña:"
          tipo="password"
          placeholder="Ingresa tu contraseña"
          valor={valores.contrasena}
          onChange={cambiar}
          error={errores.contrasena || ''}
        />

        <ErrorMensaje mensaje={errorGeneral} />
        <Boton tipo="submit">Ingresar</Boton>
      </fieldset>

      <p className="enlace-secundario">
        ¿No tienes cuenta? <Link to="/registro">Registrate aqui</Link>
      </p>
      <p className="enlace-secundario">
        <Link to="/">Volver a la pagina principal</Link>
      </p>
      <p className="enlace-secundario">Credenciales de prueba: admin@vivosonido.cl / admin123</p>
    </Form>
  )
}

export default FormularioLogin

import Navbar from 'react-bootstrap/Navbar'
import ItemMenu from '../molecules/ItemMenu'
import { construirMenu } from '../../data/menu'

// Encabezado con el menú. En pantallas chicas el menú se colapsa (React Bootstrap).
function Header({ cantidadCarrito, tema, onAlternarTema, sesion, onCerrarSesion }) {
  const items = construirMenu(sesion, cantidadCarrito)

  return (
    <header id="encabezado">
      <h1>Vivo-Sonido</h1>

      <Navbar expand="md" id="menu-principal">
        <Navbar.Toggle aria-controls="menu-colapsable" aria-label="Abrir menú" />
        <Navbar.Collapse id="menu-colapsable">
          <ul>
            {items.map((item) => (
              <ItemMenu key={item.href} href={item.href} etiqueta={item.etiqueta} />
            ))}
            {sesion && <ItemMenu href="/login" etiqueta="Cerrar sesión" onClick={onCerrarSesion} />}
            <ItemMenu
              etiqueta={tema === 'oscuro' ? 'Tema claro' : 'Tema oscuro'}
              onClick={onAlternarTema}
            />
          </ul>
        </Navbar.Collapse>
      </Navbar>
    </header>
  )
}

export default Header

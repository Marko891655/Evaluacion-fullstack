import { render, screen, fireEvent } from '@testing-library/react'
import { describe, it, expect, vi } from 'vitest'
import FormularioProducto from './FormularioProducto'

describe('FormularioProducto', () => {
  it('Debe crear el producto con imagen genérica cuando los datos son válidos', () => {
    // Arrange
    const onAgregarProducto = vi.fn()
    render(<FormularioProducto onAgregarProducto={onAgregarProducto} />)

    // Act
    fireEvent.change(screen.getByLabelText(/^nombre/i), { target: { value: 'Ukelele soprano' } })
    fireEvent.change(screen.getByLabelText(/descripción/i), { target: { value: 'Ukelele de caoba para principiantes' } })
    fireEvent.change(screen.getByLabelText(/precio/i), { target: { value: '45990' } })
    fireEvent.change(screen.getByLabelText(/stock/i), { target: { value: '7' } })
    fireEvent.change(screen.getByLabelText(/categoría/i), { target: { value: 'Cuerdas' } })
    fireEvent.click(screen.getByRole('button', { name: /agregar producto/i }))

    // Assert
    expect(onAgregarProducto).toHaveBeenCalledTimes(1)
    const creado = onAgregarProducto.mock.calls[0][0]
    expect(creado.titulo).toBe('Ukelele soprano')
    expect(creado.precio).toBe(45990)
    expect(creado.imagen).toBeTruthy()
  })

  it('Debe mostrar los errores y no crear el producto si el formulario está vacío', () => {
    // Arrange
    const onAgregarProducto = vi.fn()
    render(<FormularioProducto onAgregarProducto={onAgregarProducto} />)

    // Act
    fireEvent.click(screen.getByRole('button', { name: /agregar producto/i }))

    // Assert
    expect(screen.getByText('El nombre debe tener al menos 3 caracteres')).toBeInTheDocument()
    expect(screen.getByText('El precio es obligatorio')).toBeInTheDocument()
    expect(onAgregarProducto).not.toHaveBeenCalled()
  })
})

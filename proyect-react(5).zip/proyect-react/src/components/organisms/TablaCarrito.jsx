import Table from 'react-bootstrap/Table'
import FilaCarrito from '../molecules/FilaCarrito'

// Tabla responsive: en pantallas chicas se puede desplazar horizontalmente
function TablaCarrito({ filas, onCambiarCantidad, onQuitar }) {
  return (
    <Table responsive hover>
      <thead>
        <tr>
          <th>Producto</th>
          <th>Precio</th>
          <th>Cantidad</th>
          <th>Subtotal</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        {filas.map((fila) => (
          <FilaCarrito key={fila.id} fila={fila} onCambiarCantidad={onCambiarCantidad} onQuitar={onQuitar} />
        ))}
      </tbody>
    </Table>
  )
}

export default TablaCarrito

import { Link } from 'react-router-dom'

function ListaFavoritos({ productos }) {
  if (productos.length === 0) {
    return <p>Aún no tienes productos favoritos. Márcalos desde el catálogo.</p>
  }

  return (
    <ul className="lista-favoritos">
      {productos.map((producto) => (
        <li key={producto.id}>
          <Link to={`/producto/${producto.id}`}>{producto.titulo}</Link>
        </li>
      ))}
    </ul>
  )
}

export default ListaFavoritos

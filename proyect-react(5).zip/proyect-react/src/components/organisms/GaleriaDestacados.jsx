import TarjetaDestacada from '../molecules/TarjetaDestacada'

function GaleriaDestacados({ productos }) {
  return (
    <div className="galeria">
      {productos.map((producto) => (
        <TarjetaDestacada key={producto.id} producto={producto} />
      ))}
    </div>
  )
}

export default GaleriaDestacados

import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import CampoFormulario from '../molecules/CampoFormulario'
import { categorias } from '../../data/productos'

const opcionesCategoria = categorias.map((categoria) => ({ valor: categoria, etiqueta: categoria }))

// Filtros del catálogo: en pantallas chicas se apilan, en medianas van lado a lado
function FiltroProductos({ texto, categoria, onCambiarTexto, onCambiarCategoria }) {
  return (
    <Row xs={1} md={2} className="g-3 filtro-productos">
      <Col>
        <CampoFormulario
          id="filtro-texto"
          etiqueta="Buscar por nombre:"
          valor={texto}
          onChange={(e) => onCambiarTexto(e.target.value)}
          placeholder="Ej: guitarra"
        />
      </Col>
      <Col>
        <CampoFormulario
          id="filtro-categoria"
          etiqueta="Categoría:"
          valor={categoria}
          onChange={(e) => onCambiarCategoria(e.target.value)}
          opciones={opcionesCategoria}
          opcionVacia="Todas"
        />
      </Col>
    </Row>
  )
}

export default FiltroProductos

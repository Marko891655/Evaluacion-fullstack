import { useState } from 'react'
import ImagenProducto from '../atoms/ImagenProducto'
import Precio from '../atoms/Precio'
import Boton from '../atoms/Boton'
import Mensaje from '../atoms/Mensaje'
import SelectorCantidad from '../molecules/SelectorCantidad'
import { formatearPrecio } from '../../utils/formato'

const CANTIDAD_MAXIMA = 20

// Detalle de un producto: elegir cantidad, ver el total y agregar al carrito
function DetalleProducto({ producto, onAgregar }) {
  const [cantidad, setCantidad] = useState(1)
  const [mensaje, setMensaje] = useState('')

  const total = producto.precio * cantidad

  const sumar = () => {
    if (cantidad < CANTIDAD_MAXIMA) {
      setCantidad(cantidad + 1)
      setMensaje('')
    }
  }

  const restar = () => {
    if (cantidad > 1) {
      setCantidad(cantidad - 1)
      setMensaje('')
    }
  }

  const agregar = () => {
    onAgregar(producto.id, cantidad)
    setMensaje(`Agregaste ${cantidad} x ${producto.titulo} — Total: ${formatearPrecio(total)}`)
  }

  return (
    <div className="detalle-layout">
      <div className="detalle-imagen">
        <ImagenProducto src={producto.imagen} alt={producto.titulo} />
      </div>

      <div className="detalle-info">
        <h2>{producto.titulo}</h2>
        <p>{producto.descripcionDetallada}</p>
        <Precio valor={producto.precio} />
        <p className="info-adicional">
          {producto.infoAdicional} Categoría: {producto.categoria}. Stock disponible: {producto.stock}.
        </p>

        <SelectorCantidad cantidad={cantidad} onSumar={sumar} onRestar={restar} />

        <Precio etiqueta="Total: " valor={total} />
        <Boton onClick={agregar}>Agregar al carrito</Boton>
        <Mensaje texto={mensaje} />
      </div>
    </div>
  )
}

export default DetalleProducto

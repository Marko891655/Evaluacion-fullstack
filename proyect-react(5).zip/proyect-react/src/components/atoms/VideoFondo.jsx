function VideoFondo() {
  return (
    <video id="bg-video" autoPlay muted loop playsInline>
      <source src="/video/154415-807354120_medium.mp4" type="video/mp4" />
    </video>
  )
}

export default VideoFondo

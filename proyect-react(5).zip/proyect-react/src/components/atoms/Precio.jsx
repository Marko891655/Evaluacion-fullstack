import { formatearPrecio } from '../../utils/formato'

function Precio({ valor, etiqueta = '' }) {
  return (
    <p className="precio">
      {etiqueta}
      {formatearPrecio(valor)}
    </p>
  )
}

export default Precio

// Mensaje de confirmación (por ejemplo "Agregaste 2 x Guitarra...")
function Mensaje({ texto }) {
  return (
    <p className="mensaje-agregado" role="status">
      {texto}
    </p>
  )
}

export default Mensaje

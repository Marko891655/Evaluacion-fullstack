// Botón con el estilo del sitio. variante: 'principal' | 'secundario'
function Boton({ children, onClick, tipo = 'button', variante = 'principal', deshabilitado = false }) {
  const clase = variante === 'secundario' ? 'btn-producto btn-secundario' : 'btn-producto'

  return (
    <button type={tipo} className={clase} onClick={onClick} disabled={deshabilitado}>
      {children}
    </button>
  )
}

export default Boton

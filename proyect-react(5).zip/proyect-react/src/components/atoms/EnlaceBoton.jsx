import { Link } from 'react-router-dom'

// Enlace de react-router que se ve como botón
function EnlaceBoton({ to, children, variante = 'principal' }) {
  const clase = variante === 'secundario' ? 'btn-producto btn-secundario' : 'btn-producto'

  return (
    <Link to={to} className={clase}>
      {children}
    </Link>
  )
}

export default EnlaceBoton

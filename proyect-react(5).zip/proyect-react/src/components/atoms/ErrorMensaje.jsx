function ErrorMensaje({ mensaje }) {
  return <span className="error-mensaje">{mensaje}</span>
}

export default ErrorMensaje

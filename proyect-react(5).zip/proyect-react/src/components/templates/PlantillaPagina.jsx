import VideoFondo from '../atoms/VideoFondo'
import Header from '../organisms/Header'
import Footer from '../organisms/Footer'

// Estructura común de todas las páginas: video de fondo, encabezado, contenido y pie
function PlantillaPagina({ children, ...propsEncabezado }) {
  return (
    <>
      <VideoFondo />
      <Header {...propsEncabezado} />
      <main id="contenido">{children}</main>
      <Footer />
    </>
  )
}

export default PlantillaPagina

import { useEffect, useState } from 'react'
import { Route, Routes } from 'react-router-dom'
import Home from './pages/Home'
import Productos from './pages/Productos'
import Producto from './pages/Producto'
import Login from './pages/Login'
import Registro from './pages/Registro'
import Carrito from './pages/Carrito'
import Perfil from './pages/Perfil'
import Panel from './pages/Panel'
import Error404 from './pages/Error404'
import RutaPrivada from './routes/RutaPrivada'
import { productosIniciales } from './data/productos'
import { agregarItem, quitarItem, cambiarCantidad, contarItems } from './utils/carrito'
import { alternarFavorito } from './utils/favoritos'
import { guardarSesion, obtenerSesion, borrarSesion } from './utils/sesion'

// Todo el estado compartido vive aquí (useState) y se reparte a las páginas por props
function App() {
  const [productos, setProductos] = useState(productosIniciales)
  const [carrito, setCarrito] = useState([])
  const [favoritos, setFavoritos] = useState([])
  const [tema, setTema] = useState('oscuro')
  const [sesion, setSesion] = useState(() => obtenerSesion())

  // El tema claro se aplica con una clase en <body> (ver styles/adaptacion.css)
  useEffect(() => {
    document.body.classList.toggle('tema-claro', tema === 'claro')
  }, [tema])

  const agregarAlCarrito = (id, cantidad = 1) => setCarrito((actual) => agregarItem(actual, id, cantidad))
  const quitarDelCarrito = (id) => setCarrito((actual) => quitarItem(actual, id))
  const modificarCantidad = (id, cantidad) => setCarrito((actual) => cambiarCantidad(actual, id, cantidad))
  const vaciarCarrito = () => setCarrito([])

  const alternarFavoritoProducto = (id) => setFavoritos((actual) => alternarFavorito(actual, id))

  const agregarProducto = (producto) => setProductos((actual) => [...actual, producto])
  const eliminarProducto = (id) => {
    setProductos((actual) => actual.filter((producto) => producto.id !== id))
    setCarrito((actual) => quitarItem(actual, id))
    setFavoritos((actual) => actual.filter((favorito) => favorito !== id))
  }

  const iniciarSesion = (usuario) => {
    guardarSesion(usuario)
    setSesion(usuario)
  }

  const cerrarSesion = () => {
    borrarSesion()
    setSesion(null)
  }

  const alternarTema = () => setTema((actual) => (actual === 'oscuro' ? 'claro' : 'oscuro'))

  // Datos que necesita el encabezado en todas las páginas
  const encabezado = {
    cantidadCarrito: contarItems(carrito),
    tema,
    onAlternarTema: alternarTema,
    sesion,
    onCerrarSesion: cerrarSesion,
  }

  return (
    <Routes>
      <Route path="/" element={<Home productos={productos} encabezado={encabezado} />} />
      <Route
        path="/productos"
        element={
          <Productos
            productos={productos}
            favoritos={favoritos}
            onAlternarFavorito={alternarFavoritoProducto}
            onAgregar={agregarAlCarrito}
            encabezado={encabezado}
          />
        }
      />
      <Route
        path="/producto/:id"
        element={<Producto productos={productos} onAgregar={agregarAlCarrito} encabezado={encabezado} />}
      />
      <Route path="/login" element={<Login onIniciarSesion={iniciarSesion} encabezado={encabezado} />} />
      <Route path="/registro" element={<Registro encabezado={encabezado} />} />
      <Route
        path="/carrito"
        element={
          <Carrito
            productos={productos}
            carrito={carrito}
            onCambiarCantidad={modificarCantidad}
            onQuitar={quitarDelCarrito}
            onVaciar={vaciarCarrito}
            encabezado={encabezado}
          />
        }
      />
      <Route
        path="/perfil"
        element={
          <RutaPrivada>
            <Perfil
              sesion={sesion}
              productos={productos}
              favoritos={favoritos}
              onCerrarSesion={cerrarSesion}
              encabezado={encabezado}
            />
          </RutaPrivada>
        }
      />
      <Route
        path="/admin"
        element={
          <RutaPrivada>
            <Panel
              productos={productos}
              onAgregarProducto={agregarProducto}
              onEliminarProducto={eliminarProducto}
              encabezado={encabezado}
            />
          </RutaPrivada>
        }
      />
      <Route path="*" element={<Error404 encabezado={encabezado} />} />
    </Routes>
  )
}

export default App

# Vivo-Sonido (React)

Migración del sitio HTML + CSS + JS de Vivo-Sonido (tienda de instrumentos musicales) a React.
El diseño original se mantiene: `src/styles/style.css` es el CSS original sin modificar y
`src/styles/adaptacion.css` solo corrige lo que Bootstrap cambia.

## Cómo ejecutarlo

```bash
npm install
npm run dev      # abre http://localhost:5173
npm test         # 37 pruebas con Vitest
npm run build
```

## Usuarios de prueba (credenciales estáticas)

| Correo | Contraseña | Rol |
|---|---|---|
| admin@vivosonido.cl | admin123 | admin |
| cliente@gmail.com | cliente123 | cliente |

## Páginas (react-router-dom)

| Ruta | Página | Acceso |
|---|---|---|
| `/` | Inicio | público |
| `/productos` | Catálogo con filtros y favoritos | público |
| `/producto/:id` | Detalle de un producto | público |
| `/login` | Inicio de sesión | público |
| `/registro` | Registro de usuario | público |
| `/carrito` | Carrito y confirmación de compra | público |
| `/perfil` | Mi perfil y favoritos | solo con sesión |
| `/admin` | Panel de control (crear y eliminar productos) | solo con sesión |
| `*` | Error 404 | público |

## Estructura (Atomic Design)

```
src/
├── components/
│   ├── atoms/        Boton, EnlaceBoton, Precio, ErrorMensaje, Mensaje, ImagenProducto, VideoFondo
│   ├── molecules/    Seccion, ItemMenu, CampoFormulario, SelectorCantidad, TarjetaProducto,
│   │                 TarjetaDestacada, FilaCarrito, FilaProductoAdmin, ResumenPago
│   ├── organisms/    Header, Footer, GaleriaProductos, GaleriaDestacados, FiltroProductos,
│   │                 DetalleProducto, FormularioLogin, FormularioRegistro, FormularioProducto,
│   │                 TablaCarrito, TablaProductosAdmin, DatosPerfil, ListaFavoritos
│   └── templates/    PlantillaPagina (video + header + contenido + footer)
├── pages/            Home, Productos, Producto, Login, Registro, Carrito, Perfil, Panel, Error404
├── routes/           RutaPrivada (protege /perfil y /admin con localStorage)
├── data/             productos, usuarios, opciones, menu
├── utils/            validaciones, carrito, sesion, autenticacion, productos, favoritos, formato
└── styles/           style.css (original) y adaptacion.css
```

## Funcionalidades con `useState` (todo el estado compartido vive en `App.jsx`)

1. Carrito de compras (agregar, cambiar cantidad, quitar, confirmar compra).
2. Tema claro / oscuro (botón del menú).
3. Filtrado dinámico del catálogo (texto y categoría).
4. Favoritos (se ven en Mi perfil).
5. Selector de cantidad con total calculado en el detalle del producto.
6. CRUD en memoria: crear y eliminar productos desde el panel (imagen genérica por defecto).

## Elementos responsivos

1. Menú colapsable (React Bootstrap `Navbar`).
2. Filtros del catálogo (`Row` / `Col`, se apilan en pantallas chicas).
3. Panel de control en dos columnas que se apilan (`Row` / `Col`).
4. Tablas del carrito y del panel (`Table responsive`).
5. Galería de tarjetas y detalle del producto (`flex-wrap` del CSS original).

## Formularios

- Login: correo con formato válido y contraseña de al menos 6 caracteres.
- Registro: validaciones originales (letras, correo, contraseñas iguales) más campos de contexto de la tienda:
  instrumento principal, nivel musical, años de experiencia (numérico) y aceptación de ofertas.
- Producto (panel): nombre, descripción, precio y stock numéricos y categoría.

## Notas

- La sesión se guarda en `localStorage` (clave `sesionVivoSonido`).
- Los productos creados en el panel viven solo en memoria: se pierden al recargar la página.
- `plan_de_pruebas.md` describe las 37 pruebas unitarias.
